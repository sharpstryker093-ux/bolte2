# Site da Empresa - Guia Rápido

## O que tem aqui

- `app.py` → o "cérebro" do site (Python/Flask). Define as páginas e os dados.
- `templates/` → os arquivos HTML de cada página.
- `static/css/style.css` → o visual (cores, fontes, espaçamento).

## Como rodar o site no seu computador

1. Instale o Python (se ainda não tiver): https://www.python.org/downloads/
2. Abra o terminal/prompt de comando dentro da pasta `site_empresa`
3. Instale o Flask:
   ```
   pip install flask
   ```
4. Rode o site:
   ```
   python app.py
   ```
5. Abra o navegador em: http://127.0.0.1:5000

## Como editar o conteúdo

- **Nome, telefone, e-mail, endereço da empresa** → edite o dicionário `EMPRESA` no topo do `app.py`
- **Lista de serviços** → edite a lista `SERVICOS` no `app.py`
- **Textos das páginas** → edite os arquivos dentro de `templates/` (home.html, sobre.html, etc.)
- **Cores e visual** → edite `static/css/style.css`

## Próximos passos (quando quiser ir além)

- Adicionar um formulário de contato que envia e-mail de verdade
- Colocar fotos da empresa (coloque os arquivos em `static/` e use `<img src="{{ url_for('static', filename='nome-da-imagem.jpg') }}">`)
- Publicar o site na internet (existem serviços gratuitos como PythonAnywhere e Render, ótimos para sites Flask simples)

Qualquer dúvida nessas próximas etapas, é só perguntar!
