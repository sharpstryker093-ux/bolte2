from flask import Flask, render_template

app = Flask(__name__)

# Dados da empresa - edite aqui com as informações reais
EMPRESA = {
    "nome": "Nome da Sua Empresa",
    "slogan": "Seu slogan ou frase de efeito aqui",
    "telefone": "(00) 00000-0000",
    "email": "contato@suaempresa.com.br",
    "endereco": "Rua Exemplo, 123 - Cidade, Estado"
}

SERVICOS = [
    {"titulo": "Serviço 1", "descricao": "Descrição breve do primeiro serviço oferecido."},
    {"titulo": "Serviço 2", "descricao": "Descrição breve do segundo serviço oferecido."},
    {"titulo": "Serviço 3", "descricao": "Descrição breve do terceiro serviço oferecido."},
]


@app.route("/")
def home():
    return render_template("home.html", empresa=EMPRESA)


@app.route("/sobre")
def sobre():
    return render_template("sobre.html", empresa=EMPRESA)


@app.route("/servicos")
def servicos():
    return render_template("servicos.html", empresa=EMPRESA, servicos=SERVICOS)


@app.route("/contato")
def contato():
    return render_template("contato.html", empresa=EMPRESA)


if __name__ == "__main__":
    app.run(debug=True)
