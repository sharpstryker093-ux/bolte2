// Espaço reservado para interações futuras (menus, animações extras, etc.)
console.log("Bolte — site carregado.");
